package vn.edu.techkids.mahr.enitity;

/**
 * Created by qhuydtvt on 3/9/2016.
 */
public interface JSONPreDownloadHandler {
    void onPreDownload(String tag);
}
