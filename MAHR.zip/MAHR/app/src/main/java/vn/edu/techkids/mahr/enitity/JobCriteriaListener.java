package vn.edu.techkids.mahr.enitity;

/**
 * Created by qhuydtvt on 3/7/2016.
 */
public interface JobCriteriaListener {
    void onJobCriteriaChange();
}
